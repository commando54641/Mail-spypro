<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


$config['appId']   = '831960960234213';
$config['secret']  = '50a865edd82760f6c6ca7a8fdb3d9e77';

?>