<?php
define("ADMINLOGIN", "login_tbl");
define("SITESET", "site_setting");
define("DRAW",'purchase_tbl');
define("PROMO",'promocode_tbl');
?>  