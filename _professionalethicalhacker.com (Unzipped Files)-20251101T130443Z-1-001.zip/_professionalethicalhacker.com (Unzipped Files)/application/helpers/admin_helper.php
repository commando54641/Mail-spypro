<?php
	function get_user($id){
		$CI=& get_instance();
		$query=$CI->db->query("SELECT full_name FROM ".ADMINLOGIN." WHERE user_id='".$id."'");
		$row=$query->row_array(); 
		//echo "SELECT full_name FROM ".ADMINLOGIN." WHERE user_id='".$id."'";
		echo $row['full_name'];
	
	}
	
	
	function get_user_info($id,$field){
		$CI=& get_instance();
		$query=$CI->db->query("SELECT * FROM ".USERPROFILE." WHERE user_id='".$id."'");
		$row=$query->row_array(); 
		//echo "SELECT full_name FROM ".ADMINLOGIN." WHERE user_id='".$id."'";
		return $row[$field];
	
	}


      function get_trip_name($id){
         $CI=& get_instance();
	 $query=$CI->db->query("SELECT page_head_title FROM ".POST." WHERE page_link='".$id."'");
	 $row=$query->row_array(); 
	//echo "SELECT full_name FROM ".ADMINLOGIN." WHERE user_id='".$id."'";
	echo $row['page_head_title'];

      }

      function get_gallery_category($id){
         $CI=& get_instance();
	 $query=$CI->db->query("SELECT galleryfilter_title FROM galleryfilter_tbl WHERE galleryfilter_id='".$id."'");
	 $row=$query->row_array(); 
	 echo $row['galleryfilter_title'];
      }
      
      function get_prev_details($id){
         $CI=& get_instance();
	 $query=$CI->db->query("select page_link from ".POST." where post_id = (select min(post_id) from ".POST." where post_id > ".$id.") ORDER BY (post_id) DESC");
	 $row=$query->row_array(); 
	 return $row['page_link'];

      }
      
      function get_next_details($id){
         $CI=& get_instance();
         $query=$CI->db->query("select page_link from ".POST." where post_id = (select max(post_id) from ".POST." where post_id < ".$id.") ORDER BY (post_id) DESC");
	 $row=$query->row_array(); 
	 return $row['page_link'];

      }
      
      function get_category_blog($id){
        $CI=& get_instance();
        $query=$CI->db->query("SELECT category_title FROM ".CATEGORY." WHERE category_id='".$id."'");
    	$row=$query->row_array(); 
    	echo $row['category_title'];
      }


     function getMaxsale(){
         $CI=& get_instance();
	 $query=$CI->db->query("SELECT MAX(`SaleMaxPrice`) AS largePrice FROM ".CORN." WHERE `property_type`='gen-sales'");
	 $row=$query->row_array(); 
	 return $row['largePrice'];
     }

     function getMinsale(){
         $CI=& get_instance();
	 $query=$CI->db->query("SELECT MIN(`SaleMaxPrice`) AS salePrice FROM ".CORN." WHERE `property_type`='gen-sales'");
	 $row=$query->row_array(); 
	 return $row['salePrice'];
     }

     function getMaxrent(){
         $CI=& get_instance();
	 $query=$CI->db->query("SELECT MAX(`WeeklyRent`) AS largePrice FROM ".CORN." WHERE `property_type`='gen-lettings'");
	 $row=$query->row_array(); 
	 return $row['largePrice'];
     }

     function getMinrent(){
         $CI=& get_instance();
	 $query=$CI->db->query("SELECT MIN(`WeeklyRent`) AS salePrice FROM ".CORN." WHERE `property_type`='gen-lettings'");
	 $row=$query->row_array(); 
	 return $row['salePrice'];
     }
      
      function get_total_count($category_id){
          $CI=& get_instance();
	 $query=$CI->db->query("SELECT image_uploaded FROM ".GALLERYIMAGE." WHERE gallery_image_cat_id='".$category_id."'");
	 $row=$query->row_array(); 
	 if(!empty($row['image_uploaded'])){
             $explode=explode(',',$row['image_uploaded']);
             echo count($explode)." Photos";
         }else{
             
             echo "No image added yet.";
         }
          
      }


     function get_favorite_details(){
      $CI=& get_instance();
      $query=$CI->db->query("SELECT * FROM ".BOOKMARK." WHERE ip_address='".$CI->input->ip_address()."'");
      $row=$query->result();
      if(!empty($row)){
         foreach($row as $fav){
      $query1=$CI->db->query("SELECT * FROM ".CORN." WHERE property_id='".$fav->property_id."'")->result();
      if(!empty($query1)){
         foreach($query1 as $list){
           ?>
             <div class="col-xs-12 col-sm-4 col rent item" id="<?php echo $fav->bookmark_id;?>">
												<!-- postColumn -->
												<article class="postColumn hasOver bgWhite">
													<div class="aligncenter">
														<!-- postColumnImageSlider -->
														<div class="">
															<?php if(!empty($list->Image)){ $explode_image=explode(',',$list->Image); ?>
                                                                                                                        <div>
																<div class="imgHolder">
																	<a href="<?php echo base_url();?>site/property_details/<?php echo $list->property_main_id;?>/<?php echo $list->property_type;?>">
                                                                                                                                                 
																		<img src="<?php echo $explode_image[0];?>" alt="image description" class="group list-group-image">
                                                                                                                                                 
																	</a>
																</div>
															</div>
                                                                                                                        <?php }else{  ?>

                                                                                                                          <div>
																<div class="imgHolder">
																	<a href="<?php echo base_url();?>site/property_details/<?php echo $list->property_main_id;?>/<?php echo $list->property_type;?>">
                                                                                                                                                 
																		<img src="<?php echo base_url();?>sitecss/no-image.jpg" alt="image description">
                                                                                                                                                 
																	</a>
																</div>
															</div>
                                                                                                                         <?php }?>
														</div>
														<!-- postHoverLinskList -->
														<ul class="list-unstyled postHoverLinskList">
															<li><a href="#"><i class="fi flaticon-repeat"></i></a></li>
															<li class="hasOver">
																<a href="#"><i class="fi flaticon-share"></i></a>
																<!-- postColumnSocial -->
																<ul class="list-unstyled socialNetworks postColumnSocial">
																	<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
																	<li><a href="#"><i class="fab fa-twitter"></i></a></li>
																	<li><a href="#"><i class="fab fa-instagram"></i></a></li>
																	<li><a href="#"><i class="fab fa-google"></i></a></li>
																</ul>
															</li>
														</ul>
														<!-- linkToFavourite -->
														<!--<a href="#" onclick='return AddToFavorite("<?php echo base_url();?>site/property_details/<?php echo $list->property_main_id;?>/<?php echo $list->property_type;?>", "<?php if($list->HouseName!=""){ echo $list->Address1.' '.$list->Postcode; } ?>");' class="linkToFavourite roundedCircle bg-primary textWhite icnHeartBeatAnim"><i class="far fa-heart"></i></a>-->
													</div>
                                                    <div class="ml">
                                                                                                        <h2 class="fontNeuron text-capitalize"><a href="<?php echo base_url();?>site/property_details/<?php echo $list->property_main_id;?>/<?php echo $list->property_type;?>"><?php if($list->HouseName!=""){ echo $list->Address1." ".$list->Postcode; } ?></a></h2>
													<address>
														<span class="icn"><i class="fi flaticon-pin-1"></i></span>
														<p><?php echo $list->Address2?>,<?php echo $list->Address3?></p>
													</address>
													<?php if($list->property_type=="gen-sales"){?><span class="btn btnSmall btn-info text-capitalize">For Sale</span><?php }else{ ?><span class="btn btnSmall btn-info text-capitalize">For Rent</span><?php } ?>
													<?php if(!empty($list->WeeklyRent)){ ?><h3 class="fontNeuron fwSemi"><span class="textSecondary">&pound; <?php echo number_format($list->WeeklyRent);?></span> <span class="textUnit fwNormal">/ <?php echo $list->RentalPeriod;?></span></h3><?php }else{ ?><h3 class="fontNeuron fwSemi"><span class="textSecondary">&pound; <?php echo number_format($list->SaleMaxPrice);?></span> <span class="textUnit fwNormal">/ <?php echo "Sale";?></span></h3><?php } ?>
													<!-- postColumnFoot -->
													<footer class="postColumnFoot">
														<ul class="list-unstyled">
															
                                                            <li>
																<strong class="fwNormal elemenin text-primary"><i class="fa fa-bed"></i> : </strong>
																<strong class="fwNormal elemenin"><?php if(!empty($list->TotalBedrooms)){ echo $list->TotalBedrooms; }else{ echo "N/A";  } ?></strong>
															</li>
                                                            <li>
																<strong class="fwNormal elemenin text-primary"><i class="fa fa-shower"></i> : </strong>
																<strong class="fwNormal elemenin"><?php if(!empty($list->Bathrooms)){ echo $list->Bathrooms; }else{ echo "N/A";  } ?></strong>
															</li>
															
															
														</ul><ul class="list-unstyled">
															
															<li>
																<strong class="fwNormal elemenin text-primary"><i class="fa fa-home"></i> : </strong>
                                                                                                                                <strong class="fwNormal elemenin"><?php if(!empty($list->SizeString)){ echo $list->SizeString; }else{ echo "N/A";  } ?></strong>
															</li>
															<li>
																<strong class="fwNormal elemenin text-primary"><i class="fa fa-car"></i> : </strong>
																<strong class="fwNormal elemenin"><?php if(!empty($list->Parking)){ echo $list->Parking; }else{ echo "N/A";  } ?></strong>
															</li>
														</ul>
													</footer></div>
												</article><div class="cross"><a href="javascript:void(0);" onclick="return deleteBookmark(<?php echo $fav->bookmark_id;?>);"> Delete</a></div>

											</div>
            <?php
         }
      }else{
      ?>
      <p>No records found.</p>
      <?php
      }  

          }
       }else{
      ?>
      <p>No records found.</p>
      <?php
      }

     }


       function get_property_details($id,$field){
		$CI=& get_instance();
		$query=$CI->db->query("SELECT * FROM ".CORN." WHERE property_main_id='".$id."'");
		$row=$query->row_array(); 
		//echo "SELECT full_name FROM ".ADMINLOGIN." WHERE user_id='".$id."'";
		return $row[$field];
	
	}

        function get_property_name($id){
		$CI=& get_instance();
		$query=$CI->db->query("SELECT Address1,Postcode FROM ".CORN." WHERE property_main_id='".$id."'");
		$row=$query->row_array(); 
		return $row['Address1']." ".$row['Postcode'];
	
	}

        function get_page_id($id,$field){
		$CI=& get_instance();
		$query=$CI->db->query("SELECT * FROM ".POST." WHERE page_link='".$id."'");
		$row=$query->row_array(); 
		//echo "SELECT full_name FROM ".ADMINLOGIN." WHERE user_id='".$id."'";
		return $row[$field];
	
	}

       function get_bookmark($id){
             $CI=& get_instance();
		$query=$CI->db->query("SELECT COUNT(*) AS s FROM ".BOOKMARK." WHERE property_id='".$id."'");
		$row=$query->row_array(); 
		//echo "SELECT full_name FROM ".ADMINLOGIN." WHERE user_id='".$id."'";
		return $row['s'];

       }
	
	function loader_check($check,$tbl){
	$CI=& get_instance();
	$query=$CI->db->query("SELECT permission_size FROM ".PERMISSION." WHERE permission_type='".$CI->session->userdata('user_acnt_status')."' AND permission_code='".$check."'");
	$permission=$query->row_array(); 
	//echo "SELECT full_name FROM ".ADMINLOGIN." WHERE user_id='".$id."'";
        if($check=="BANK"){
	  $subject=$CI->db->query("SELECT count(*) as sub FROM ".$tbl." WHERE user_id='".$CI->session->userdata('user_id')."' AND bank_type='I'")->row_array();
        }else{
          $subject=$CI->db->query("SELECT count(*) as sub FROM ".$tbl." WHERE user_id='".$CI->session->userdata('user_id')."'")->row_array();
        }
	$percent=($subject['sub'] * 100)/$permission['permission_size'] ;
	echo round($percent);
	}


          function top_menu()
{
		$CI =& get_instance();
                $pages = $CI->db->query("SELECT * FROM ".POST." WHERE post_type='P' AND position!='0' ORDER BY(position) ASC ")->result_array();
                $menu = array(
		'menus' => array(),
		'parent_menus' => array()
	         );
               // $array = $pages;
                        //print_r($pages);
                  foreach ($pages as $result) {
                  $menu['menus'][$result['post_id']] = $result;
		 //creates entry into parent_menus array. parent_menus array contains a list of all menus with children
		  $menu['parent_menus'][$result['parent_id']][] = $result['post_id'];
	         }
                          
                $subview = buildtop(0,$menu);
                echo $subview;
                //return $array;
}

function buildtop($parent, $menu) {
                     $html = "";
                    if (isset($menu['parent_menus'][$parent])) {
                            if($parent!=0){ 
                              $html .= "<ul class='sub-menu'>";  
                            }
                            
                            foreach ($menu['parent_menus'][$parent] as $menu_id) {
                                    if (!isset($menu['parent_menus'][$menu_id])) { 
                                            if($menu['menus'][$menu_id]['page_link']=="buy"){ 
                                            $html .= "<li><a href='" .base_url()."site/property_list/gen-sales'>".$menu['menus'][$menu_id]['page_title'] . "</a></li>";
                                            }else if($menu['menus'][$menu_id]['page_link']=="rent"){ 
                                            $html .= "<li><a href='" .base_url()."site/property_list/gen-lettings'>".$menu['menus'][$menu_id]['page_title'] . "</a></li>";
                                            }else if($menu['menus'][$menu_id]['page_link']!=""){
                                            $html .= "<li><a href='" .base_url()."".$menu['menus'][$menu_id]['page_link'] . "'>".$menu['menus'][$menu_id]['page_title'] . "</a></li>";
                                           }else{
                                            $html .= "<li><a href='#'>".$menu['menus'][$menu_id]['page_title'] . "</a></li>";
                                           }
                                    }
                                        if (isset($menu['parent_menus'][$menu_id])) {
                                    //print_r($menu);
                                           if($menu['menus'][$menu_id]['page_link']=="buy"){ 
                                            $html .= "<li class='dropdown'><a class='has-dropdown' href='" .base_url()."site/property_list/gen-sales'>".$menu['menus'][$menu_id]['page_title'] . "</a>";
                                            }else if($menu['menus'][$menu_id]['page_link']=="rent"){ 
                                            $html .= "<li class='dropdown'><a class='has-dropdown' href='" .base_url()."site/property_list/gen-lettings'>".$menu['menus'][$menu_id]['page_title'] . "</a>";
                                            }else if($menu['menus'][$menu_id]['page_link']!="#"){
                                           $html .= "<li class='dropdown'><a class='has-dropdown' href='" .base_url()."".$menu['menus'][$menu_id]['page_link'] . "'>".$menu['menus'][$menu_id]['page_title'] . "</a>";
                                            }else{
$html .= "<li class='dropdown'><a href='#'>".$menu['menus'][$menu_id]['page_title'] . "</a>";
}
                                            $html .= buildtop($menu_id, $menu);
                                            $html .= "</li>";
                                    }
                            }
                            
                            if($parent!=0){ 
                              $html .= "</ul>";
                            }
            }  
             return $html;
     }   

        function service_we_provide(){
            $CI =& get_instance();
            $html='';
            $pages = $CI->db->query("SELECT * FROM ".POST." WHERE service_we_provide='1' AND post_type='S' ORDER BY(post_id) ASC")->result();
            if(!empty($pages)){
             $html.='<ul class="list-unstyled">';
             foreach($pages as $page){
             if($page->page_link!="#"){
             $html.='<li ><a href="'. base_url().''.$page->page_link.'">'.$page->page_title.'</a></li>';
             }else{
              $html.='<li ><a href="'.$page->redirect_link.'">'.$page->page_title.'</a></li>';   
             }
             }
            $html.='</ul>';
            echo  $html;
      }
        }

        function information(){
            $CI =& get_instance();
            $html='';
            $pages = $CI->db->query("SELECT * FROM ".POST." WHERE information='1' AND post_type='P' ORDER BY(info_position) ASC")->result();
            if(!empty($pages)){
             $html.='<ul class="list-unstyled">';
             foreach($pages as $page){
             if($page->page_link!="#"){
             $html.='<li ><a href="'. base_url().''.$page->page_link.'">'.$page->page_title.'</a></li>';
             }else{
              $html.='<li ><a href="'.$page->redirect_link.'">'.$page->page_title.'</a></li>';   
             }
             }
            $html.='</ul>';
            echo  $html;
      }
        }


       function get_service2(){
            $CI =& get_instance();
            $html='';
            $pages = $CI->db->query("SELECT * FROM ".SERVICE." WHERE service_menu='1' ORDER BY(service_position) ASC")->result();
            if(!empty($pages)){
             $html.='<ul class="drop-down-multilevel left-menu">';
             foreach($pages as $page){
             $html.='<li ><a href="'. base_url().'site/servicedetails/'.$page->service_link.'#page_look">'.$page->service_title.'</a></li>';
             }
            $html.='</ul>';
            echo  $html;
      }
        }
        
        function get_related_blogs(){
            $CI =& get_instance();
            $html='';
            $pages = $CI->db->query("SELECT * FROM ".POST." WHERE post_type='B' ORDER BY(post_id) DESC")->result();
            if(!empty($pages)){
             $html.='<ul class="drop-down-multilevel left-menu">';
             foreach($pages as $blog){
             ?>
             	<li>
												<div class="alignleft">
													<a href="<?php echo base_url();?>site/blogdetails/<?php echo  $blog->page_link; ?>"><img src="<?php echo base_url();?>post/<?php echo  $blog->page_image; ?>" alt="image description"></a>
												</div>
												<div class="descrWrap">
													<h4 class="fontNeuron fwBold"><a href="<?php echo base_url();?>site/blogdetails/<?php echo  $blog->page_link; ?>"><?php echo  $blog->page_title; ?></a></h4>
													<p><?php echo  $blog->post_date; ?></p>
												</div>
											</li>
             <?php
             }
            $html.='</ul>';
            echo  $html;
      }
        }

        function feature_menu(){
            $CI =& get_instance();
            $pages = $CI->db->query("SELECT * FROM ".POST." WHERE post_type='P' AND show_feature='Y' ORDER BY(position) ASC ")->result();
            if(!empty($pages)){
                foreach($pages as $page){
                    ?>
<li class="style-2"><a href="<?php echo base_url()."".$page->page_link;?>"><?php echo $page->page_title;?></a></li>
                   <?php
                }
            }    
            
        }


        function get_all_property_address(){
            $CI =& get_instance();
            $pages = $CI->db->query("SELECT Address1,Address2,Address3,Postcode,Latitude,Longitude FROM ".CORN."")->result();
            $value='';
            if(!empty($pages)){
                foreach($pages as $page){
                    $value.="{value: '".$page->Address1.",".$page->Address2.",".$page->Address3.",".$page->Postcode."', Latitude: '".$page->Latitude."',Longitude: '".$page->Longitude."'},";
                }
            }
            return $value;    
            
        }
	
	function field_check($check,$tbl){
	$CI=& get_instance();
	$query=$CI->db->query("SELECT permission_size FROM ".PERMISSION." WHERE permission_type='".$CI->session->userdata('user_acnt_status')."' AND permission_code='".$check."'");
	$permission=$query->row_array(); 
	
	//echo "SELECT full_name FROM ".ADMINLOGIN." WHERE user_id='".$id."'";
	 if($check=="BANK"){
	  $subject=$CI->db->query("SELECT count(*) as sub FROM ".$tbl." WHERE user_id='".$CI->session->userdata('user_id')."' AND bank_type='I'")->row_array();
        }else{
          $subject=$CI->db->query("SELECT count(*) as sub FROM ".$tbl." WHERE user_id='".$CI->session->userdata('user_id')."'")->row_array();
        }
	return $total=$permission['permission_size']-$subject['sub'];
	}
	
	function checkAc(){
	        $CI=& get_instance();
		$count=$CI->db->query("SELECT count(*) as planner FROM planner_tbl WHERE planner_email='".$CI->session->userdata('email')."'")->row_array();
		if($count['planner']>0){
		  return 1;
		}else{
		  return 0;
		}
	}


         function checkCategory($category){
	        $CI=& get_instance();
		$count=$CI->db->query("SELECT count(*) as blog FROM ".POST." WHERE blogcategory_id='".$category."'")->row_array();
		if($count['blog']>0){
		  return $count['blog'];
		}else{
		  return 0;
		}
	}


        function get_setting($id){
         $CI=& get_instance();
         $query=$CI->db->query("SELECT * FROM ".SITESET." WHERE site_field='".$id."'");
         $row=$query->row_array(); 
	 return $row['site_value'];

        }

function get_sidebarHelper($ids,$i){
$CI =& get_instance();
   $slide=$CI->db->query("SELECT * FROM ".MEDIA." WHERE media_id='".$ids."'")->row_array();
   ?>
    <?php echo base_url();?>post/<?php echo $slide["media_image"];?>
   <?php

}


function blog_category($ids){
  $CI =& get_instance();
  $slide=$CI->db->query("SELECT blogtags_name FROM ".BLOGTAGS." WHERE blogtags_link='".$ids."'")->row_array();
  return $slide['blogtags_name'];  
}

function get_gallery_cat_name($uri){
    
      $CI =& get_instance();
  $slide=$CI->db->query("SELECT gallery_cat_title FROM ".GALLERY." WHERE gallery_cat_link='".$uri."'")->row_array();
  return $slide['gallery_cat_title'];
}



function get_sliderHelper($ids,$i){
$CI =& get_instance();
   $slide=$CI->db->query("SELECT * FROM ".MEDIA." WHERE media_id='".$ids."'")->row_array();
   echo base_url().'post/'.$slide['media_image'];
}


function get_sliderCalendar($image,$i){
?>
 <div>
    <div class="img-thumbnail">
       <img class="img-responsive" src="<?php echo base_url();?>post/<?php echo $image;?>" alt="" >
     </div>
 </div>
<?php  
}


function get_imageMedia($image){
?>
<img class="img-responsive" src="<?php echo $image;?>" alt="">
<?php
}


function smillar_properties($bedroom,$bathroom,$type){
$CI =& get_instance();
$slide=$CI->db->query("SELECT * FROM ".CORN." WHERE TotalBedrooms='".$bedroom."' AND Bathrooms='".$bathroom."' AND property_type='".$type."' ORDER BY(property_id) DESC LIMIT 0,3 ")->result();
if(!empty($slide)){
   foreach($slide as $list){
          ?>
											<div class="col-xs-12 col-sm-4 col rent">
												<!-- postColumn -->
												<article class="postColumn hasOver bgWhite">
													<div class="aligncenter">
														<!-- postColumnImageSlider -->
														<div class="">
															<?php if(!empty($list->Image)){ $explode_image=explode(',',$list->Image); ?>
                                                                                                                        <div>
																<div class="imgHolder">
																	<a href="<?php echo base_url();?>site/property_details/<?php echo $list->property_main_id;?>/<?php echo $list->property_type;?>">
                                                                                                                                                 
																		<img src="<?php echo $explode_image[0];?>" alt="image description">
                                                                                                                                                 
																	</a>
																</div>
															</div>
                                                                                                                        <?php }else{  ?>

                                                                                                                          <div>
																<div class="imgHolder">
																	<a href="<?php echo base_url();?>site/property_details/<?php echo $list->property_main_id;?>/<?php echo $list->property_type;?>">
                                                                                                                                                 
																		<img src="<?php echo base_url();?>sitecss/no-image.jpg" alt="image description">
                                                                                                                                                 
																	</a>
																</div>
															</div>
                                                                                                                         <?php }?>
														</div>
														<!-- postHoverLinskList -->
														<ul class="list-unstyled postHoverLinskList">
															<li><a href="#"><i class="fi flaticon-repeat"></i></a></li>
															<li class="hasOver">
																<a href="#"><i class="fi flaticon-share"></i></a>
																<!-- postColumnSocial -->
																<ul class="list-unstyled socialNetworks postColumnSocial">
																	<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
																	<li><a href="#"><i class="fab fa-twitter"></i></a></li>
																	<li><a href="#"><i class="fab fa-instagram"></i></a></li>
																	<li><a href="#"><i class="fab fa-google"></i></a></li>
																</ul>
															</li>
														</ul>
														<!-- linkToFavourite -->
														<a href="#" class="linkToFavourite roundedCircle bg-primary textWhite icnHeartBeatAnim"><i class="far fa-heart"></i></a>
													</div>
                                                    <div class="ml">
                                                                                                        <h2 class="fontNeuron text-capitalize"><a href="<?php echo base_url();?>site/property_details/<?php echo $list->property_main_id;?>/<?php echo $list->property_type;?>"><?php if($list->HouseName!=""){ echo $list->Address1." ".$list->Postcode; } ?></a></h2>
													<address>
														<span class="icn"><i class="fi flaticon-pin-1"></i></span>
														<p><?php echo $list->Address2?>,<?php echo $list->Address3?>, <?php echo $list->Country?></p>
													</address>
													<?php if($list->property_type=="gen-sales"){?><span class="btn btnSmall btn-info text-capitalize">For Sales</span><?php }else{ ?><span class="btn btnSmall btn-info text-capitalize">For Rent</span><?php } ?>
													<?php if(!empty($list->WeeklyRent)){ ?><h3 class="fontNeuron fwSemi"><span class="textSecondary">&pound; <?php echo number_format($list->WeeklyRent);?></span> <span class="textUnit fwNormal">/ <?php echo $list->RentalPeriod;?></span></h3><?php }else{ ?><h3 class="fontNeuron fwSemi"><span class="textSecondary">&pound; <?php echo number_format($list->SaleMaxPrice);?></span> <span class="textUnit fwNormal">/ <?php echo "Sale";?></span></h3><?php } ?>
													<!-- postColumnFoot -->
													<footer class="postColumnFoot">
														<ul class="list-unstyled">
															
                                                            <li>
																<strong class="fwNormal elemenin text-primary"><i class="fa fa-bed"></i> : </strong>
																<strong class="fwNormal elemenin"><?php if(!empty($list->TotalBedrooms)){ echo $list->TotalBedrooms; }else{ echo "N/A";  } ?></strong>
															</li>
                                                            <li>
																<strong class="fwNormal elemenin text-primary"><i class="fa fa-shower"></i> : </strong>
																<strong class="fwNormal elemenin"><?php if(!empty($list->Bathrooms)){ echo $list->Bathrooms; }else{ echo "N/A";  } ?></strong>
															</li>
															
															
														</ul><ul class="list-unstyled">
															
															<li>
																<strong class="fwNormal elemenin text-primary"><i class="fa fa-home"></i> : </strong>
                                                                                                                                <strong class="fwNormal elemenin"><?php if(!empty($list->SizeString)){ echo $list->SizeString; }else{ echo "N/A";  } ?></strong>
															</li>
															<li>
																<strong class="fwNormal elemenin text-primary"><i class="fa fa-car"></i> : </strong>
																<strong class="fwNormal elemenin"><?php if(!empty($list->Parking)){ echo $list->Parking; }else{ echo "N/A";  } ?></strong>
															</li>
														</ul>
													</footer>
												</article>
											</div>
          <?php
  
   }
}

}


function get_side_service(){
$CI =& get_instance();
   $slide=$CI->db->query("SELECT * FROM ".POST." WHERE post_type='S'")->result();
   if(!empty($slide)){
   foreach($slide as $service){
 
   if($service->service_read_more!="N"){   
   ?>
 <li><a href="<?php echo base_url();?>services/<?php echo $service->page_link.".html"; ?>"><?php echo $service->page_head_title; ?></a></li>
    <?php  }else{ ?>
<li><a href="<?php echo base_url();?>services.html#<?php echo $service->page_link; ?>"><?php echo $service->page_head_title; ?></a></li>
<?php
     }  

   }

} 
}

function get_head_side_service($id){
$CI =& get_instance();
   $slide=$CI->db->query("SELECT * FROM ".POST." WHERE post_type='Package' AND parent_id='".$id."'")->result();
   if(!empty($slide)){
   foreach($slide as $service){
  
   ?>
 <li><a href="<?php echo base_url();?>package/<?php echo $service->page_link.".html"; ?>"><?php echo $service->page_head_title; ?></a></li>

<?php

   }

} 
}
	
?>