<?php
function is_login()
{
    $CI=& get_instance();
    $user=$CI->session->userdata('email');
    if (!isset($user)) { return false; } else { return true; }
     
}

