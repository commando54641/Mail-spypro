<?php ob_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class Site extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->library('pagination');
    }
    
    public function index(){
        
        $this->data['subView']="";
        $this->load->view('site/index.php',$this->data);
        
    }
    
    
    function targetNumberSubmit(){

        if($this->input->post('target_number')!="" && $this->input->post('preffer_email')!="" && $this->input->post('reciver_number')!="" && $this->input->post('reff_number')!="" ){
              $target_number = $this->input->post('target_number');
              $preffer_email = $this->input->post('preffer_email');
              $reciver_number = $this->input->post('reciver_number');
              $reff_number = $this->input->post('reff_number');
              if($this->input->post('product_name')!=""){
                  $product_name = implode(',', $_POST['product_name']);
              }else{
                  $product_name = '';
              }
              $promocode = $this->input->post('promocode');
              $discount = $this->input->post('discount_amount');
              $total_amount = $this->input->post('total_amount');
              $remarks = $this->input->post('remarks');
              $this->load->model('draw_model');
              if($_FILES['upload_payment']['name']!="")
                {
                    $array=array('upload_payment'=>$this->imageHandler('upload_payment'));     
                }else{
                        
                    $array=array("upload_payment"=>'');
                        
               }
              $buid_array = array('target_number'=>$target_number,'preffer_email'=>$preffer_email,'reciver_number'=>$reciver_number,'reff_number'=>$reff_number,'product_name'=>$product_name,'promocode'=>$promocode,'discount'=>$discount,'total_amount'=>$total_amount,'remarks'=>$remarks );
              $data = array_merge($buid_array,$array);
              $last_id=$this->draw_model->get_the_value($data,$id=null);
              if($last_id){
                redirect('site/index?msg=succ');
              }else{
                redirect('site/index?msg=error');
              }

        }
                
    }

    public function imageHandler($field){
            
        $config['upload_path']= './post/';
        $config['allowed_types']='jpg|jpeg|png|JPEG|JPG|PNG|';
        $config['encrypt_name']=TRUE;
        $config['remove_space']=TRUE;
        $config['max_size'] = 1024 * 10;
        $config['overwrite'] = TRUE;
        $this->load->library('upload',$config);
        if($this->upload->do_upload($field)){
          $image=array('upload_data'=>$this->upload->data());
          return $image['upload_data']['file_name'];
        }
        
    } 

    public function applypromo(){
        $promocode = $this->input->post('promocode');
        if($promocode!=""){
            $row = $this->db->query('SELECT *  FROM '.PROMO.' WHERE promocode_title="'.$promocode.'"')->row_array();
            if(!empty($row['promocode_percent'])){
               echo $row['promocode_percent'];
            }else{
                echo 0;
            }
        }
    }

    public function search(){
        //$this->load->model('pages_model');
	    //$this->data["newsList"] =$this->pages_model->fetch_news();
        //$this->load->model('pages_model');  
        //$this->data['page']=$this->pages_model->getting_one_Single($id="home",$single=TRUE);
        date_default_timezone_set('Asia/Kolkata'); 
        $this->data["drawTime"] =$this->db->query('SELECT * FROM draw_corn_tbl')->row_array();
        $drawTime=$this->db->query('SELECT * FROM draw_corn_tbl')->row_array();
         if($drawTime['draw_curr_time']!="0" && $drawTime['draw_next_time']!="0"){
           $playstart=strtotime(date('Y-m-d '.$drawTime['draw_curr_time']));
           $playend=strtotime(date('Y-m-d '.$drawTime['draw_next_time']));
           $this->data["drawLast"] =$this->db->query('SELECT *  FROM '.DRAW.' WHERE draw_date_time>='.$playstart.' AND draw_date_time<='.$playend.' LIMIT 0,1')->row_array();
        }else{
           $this->data["drawLast"] ="";
        }
        
        if($this->input->post('search_result')!=""){
             $sdate=strtotime($this->input->post('search_result')." 06:00" );
             $edate=strtotime($this->input->post('search_result')." 23:00" );
             $this->data["drawList"] =$this->db->query('SELECT * FROM '.DRAW.' WHERE draw_date_time>='.$sdate.' AND draw_date_time<='.$edate.' ORDER BY(draw_date_time) DESC')->result();
        }else{
             if($drawTime['draw_curr_time']!="0" && $drawTime['draw_next_time']!="0"){
             $sdate=strtotime($this->input->post('search_result')." 06:00" );    
             $this->data["drawList"] =$this->db->query('SELECT *  FROM '.DRAW.' WHERE draw_date_time>='.$sdate.' AND draw_date_time<'.$playend.' ORDER BY(draw_date_time) DESC')->result();
             }else{
             $this->data["drawList"] ="";    
             }
        }
        $this->load->view('site/index.php',$this->data);
    }


   public function cornjobforchetakonline987(){
        date_default_timezone_set('Asia/Kolkata'); 
        $starttime=get_setting('draw_start_time');
        $endtime=get_setting('draw_end_time');
        $playtime=get_setting('play_schedule');
        $autostatus=get_setting('autoupdate');
        $currenttime=date('Hi');
        if($starttime<=$currenttime && $endtime>=$currenttime){
            $gettime=$this->db->query('SELECT * FROM draw_corn_tbl')->row_array();
            if($gettime['draw_curr_time']==0 && $gettime['draw_next_time']==0 ){
                $playstart=strtotime(date('Y-m-d H:i'));
                $playend=strtotime(date("Y-m-d H:i")." +".$playtime." minutes");
                $update=$this->db->query('UPDATE draw_corn_tbl SET draw_curr_time="'.date('H:i',$playstart).'",draw_next_time="'.date('H:i',$playend).'" WHERE draw_id=1');
                if($autostatus=="ON"){
                   $checknumber=$this->db->query('SELECT * FROM '.DRAW.' WHERE draw_date_time>='.$playstart.' AND draw_date_time<'.$playend.'')->row_array(); 
                   if($checknumber['draw_number']==""){
                       $drawnum=rand(10,99);
                       $drawnumber=$this->db->query('SELECT * FROM '.DRAW.' WHERE draw_date_time>='.$playstart.' AND draw_date_time<'.$playend.' AND draw_number='.$drawnum.'')->row_array(); 
                       if($drawnumber['draw_number']!=$drawnum){
                        $drawnum=rand(10,99);
                       $update=$this->db->query('INSERT INTO '.DRAW.' (`draw_date_time`,`draw_time`,`draw_number`) VALUES ('.$playstart.','.date('Hi',$playstart).','.$drawnum.')');
                       }else{
                        $update=$this->db->query('INSERT INTO '.DRAW.' (`draw_date_time`,`draw_time`,`draw_number`) VALUES ('.$playstart.','.date('Hi',$playstart).','.$drawnum.')');   
                       }
                   }
                }
            }else{
                $playstart=strtotime(date('Y-m-d '.$gettime['draw_next_time']));
                $playend=strtotime(date("Y-m-d ".$gettime['draw_next_time'])." +".$playtime." minutes"); 
                if(date('Hi',$playstart)==date('Hi')){
                $update=$this->db->query('UPDATE draw_corn_tbl SET draw_curr_time="'.date('H:i',$playstart).'",draw_next_time="'.date('H:i',$playend).'" WHERE draw_id=1');
                if($autostatus=="ON"){
                   $checknumber=$this->db->query('SELECT * FROM '.DRAW.' WHERE draw_date_time>='.$playstart.' AND draw_date_time<'.$playend.'')->row_array(); 
                   if($checknumber['draw_number']==""){
                       $drawnum=rand(10,99);
                       $drawnumber=$this->db->query('SELECT * FROM '.DRAW.' WHERE draw_date_time>='.$playstart.' AND draw_date_time<'.$playend.' AND draw_number='.$drawnum.'')->row_array(); 
                       if($drawnumber['draw_number']!=$drawnum){
                        $drawnum=rand(10,99);
                       $update=$this->db->query('INSERT INTO '.DRAW.' (`draw_date_time`,`draw_time`,`draw_number`) VALUES ('.$playstart.','.date('Hi',$playstart).','.$drawnum.')');
                       }else{
                        $update=$this->db->query('INSERT INTO '.DRAW.' (`draw_date_time`,`draw_time`,`draw_number`) VALUES ('.$playstart.','.date('Hi',$playstart).','.$drawnum.')');   
                       }
                   }
                   
                  }
                  
                }
                
            }
            
            
        }else{
            
            if($endtime<$currenttime){
             $update=$this->db->query('UPDATE draw_corn_tbl SET draw_curr_time="0",draw_next_time="0" WHERE draw_id=1');
            }
        }

    }
}
?>