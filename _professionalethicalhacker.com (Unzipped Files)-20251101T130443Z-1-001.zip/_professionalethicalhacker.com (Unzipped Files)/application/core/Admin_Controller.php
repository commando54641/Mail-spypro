<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_Controller extends CI_Controller {
    
        function __construct()
        {
            parent::__construct();
            $this->data['meta_title'] = 'Kongratz';
            $this->data['side_title'] = 'Kongratz';
            $this->data['Active_menu'] = $this->uri->segment(2);
            $this->output->set_header("Expires: Thu, 19 Nov 1981 08:52:00 GMT");
            $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
            //;
            //cho  $this->uri->segment(3);
                //die();
            if(is_login()!=true && $this->uri->segment(1)!="login"){
               redirect('site');
             }
            
            
        }
        
        
        
}