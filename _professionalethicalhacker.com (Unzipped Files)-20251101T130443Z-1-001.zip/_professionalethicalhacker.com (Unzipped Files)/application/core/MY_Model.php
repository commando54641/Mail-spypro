<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MY_Model extends CI_Model {

        protected $_primary_filter = 'intval';
        protected $_primary_key = 'id';
        protected $_primary_type = 'type';
        
                
          function __construct() {
              parent::__construct();
          }
          
          function array_form_post($fields){
              $data=array();
              foreach($fields as $field){
                  $data[$field] = $this->input->post($field);
                  
              }
              return $data;
          }
          
          
          
          function save($data,$table,$id,$prifix){
              if($id==0){
                  
                  $this->db->set($data);
		  $this->db->insert($table);
		  $id = $this->db->insert_id();
                  
              }else{
                  
                $filter = $this->_primary_filter;
		$id = $filter($id);
                $this->db->set($data);
                $this->db->where($prifix."_".$this->_primary_key, $id);
                $this->db->update($table);
                  
              }
              return $id;
          }
          
          function postSave($data,$table,$id,$prifix){
              if($id==""){
                  
                  $this->db->set($data);
		  $this->db->insert($table);
		  $id = $this->db->insert_id();
                  
              }else{
                  
                $filter = $this->_primary_filter;
		$this->db->set($data);
                $this->db->where($prifix."_".$this->_primary_type, $id);
                $this->db->update($table);
                  
              }
              return $id;
          }
           
          
          function postGet($single,$id,$prifix,$table){
             
              if($id!=NULL){
                  $this->db->where($prifix."_".$this->_primary_type, $id);
                  $method="row_array";
              }elseif($single==true){
                  
                  $method="row";
              }else{
                  
                  $method="result";
              }
              
             
              return $this->db->get($table)->$method();
              
          }
          
          function get($single,$id,$prifix,$table){
              
              if($id!=NULL){
                  
                  $filter=$this->_primary_filter;
                  $id=$filter($id);
                  $this->db->where($prifix."_".$this->_primary_key, $id);
                  $method="row_array";
              }elseif($single==true){
                  
                  $method="row";
              }else{
                  
                  $method="result";
              }
              
             
              return $this->db->get($table)->$method();
              
          }
          
          public function get_by($where, $single = FALSE,$table){
		$this->db->where($where,which);
                if($single == FALSE){
                    $method="result";
                }else{
                    $method="row";
                }
		return $this->get($table)->$method;
	}
    
        public function get_multiple_data($datas,$single,$table){
                
              
		if($single == FALSE){
                    
                    $method="result";
                }else{
                    
                    $method="row";
                    
                }
                 foreach($datas as $key=>$data){
                    $this->db->where($key,$data);
                }
		return $this->db->get($table)->$method();
	}
         
    
        
        
        
        function delete($id,$table,$prefix){
            
            $filter=$this->_primary_filter;
            $id=$filter($id);
            if(!$id){
                return false;
            }
            $this->db->where($prefix."_".$this->_primary_key, $id);
            $this->db->limit(1);
	    $this->db->delete($table);
        }
        
        
        
        
        public function NewInsertModel($key,$value,$table){
       
       $Sucmsg='';
       $this->db->set('field_name', $key); 
       $this->db->set('field_value', $value);
       $insert=$this->db->insert($table); 
       if($insert){
           
           $Sucmsg.=$key."Insertion Successfull.."; 
           echo $Sucmsg;
           
       }
        
   }
   
   public function NewUpdateModel($key,$value,$table){
       
       $Sucmsg='';
       $this->db->where('field_name',$key);
       $this->db->set('field_value', $value);
       $insert=$this->db->update($table); 
       if($insert){
           
           $Sucmsg.=$key." Updation Successfull.."; 
           return $Sucmsg;
           
       }
       
   } 
        
}